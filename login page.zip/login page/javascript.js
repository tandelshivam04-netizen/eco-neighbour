const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});


// ================= CREATE ACCOUNT =================

document.querySelector(".sign-up form").addEventListener("submit", function (e) {
    e.preventDefault();

    const name = document.getElementById("signupName").value;
    const email = document.getElementById("signupEmail").value;
    const password = document.getElementById("signupPassword").value;

    if (name === "" || email === "" || password === "") {
        alert("Fill all fields!");
        return;
    }

    let users = JSON.parse(localStorage.getItem("users")) || [];

    // check if user already exists
    let exists = users.some(user => user.email === email);

    if (exists) {
        alert("Account already exists!");
        return;
    }

    users.push({
        name: name,
        email: email,
        password: password
    });

    localStorage.setItem("users", JSON.stringify(users));

    alert("Account created successfully! Now login.");

    container.classList.remove("active");
});


// ================= LOGIN =================

document.querySelector(".sign-in form").addEventListener("submit", function (e) {
    e.preventDefault();

    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;

    let users = JSON.parse(localStorage.getItem("users")) || [];

    let validUser = users.find(user =>
        user.email === email && user.password === password
    );

    if (validUser) {
        alert("Login successful!");

        // redirect to homepage
        window.location.href = "http://localhost:8080/";

    } else {
        alert("Invalid email or password!");
    }
});